# Design System Specification: Institutional Web3 Excellence

## 1. Overview & Creative North Star
### The Creative North Star: "The Digital Sovereign"
This design system is engineered to bridge the gap between the raw power of decentralized finance and the polished authority of traditional institutional banking. We are not building a "crypto app"; we are building a high-fidelity command center. 

The aesthetic is **"The Digital Sovereign"**—a philosophy that prioritizes clarity, depth, and intentionality. We break the "template" look by eschewing standard grids in favor of **Dynamic Asymmetry**. By utilizing significant whitespace (from our `24` and `20` spacing tokens) and overlapping glass layers, we create a UI that feels like an advanced heads-up display rather than a flat webpage.

---

## 2. Colors & Surface Philosophy
The palette is rooted in deep space grays, punctuated by high-energy accents that signify "live" data and liquidity.

### The "No-Line" Rule
Traditional 1px solid borders are strictly prohibited for sectioning. Structural definition must be achieved through **Tonal Transitions**. 
*   **Surface Shifting:** Use `surface_container_low` for the page background and `surface_container` for the primary content area. The 4% difference in luminosity creates a sophisticated boundary that feels organic, not drawn.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of semi-transparent materials.
*   **Base:** `surface` (#131314)
*   **Level 1 (Sections):** `surface_container_low`
*   **Level 2 (Cards):** `surface_container_high` (20px radius)
*   **Level 3 (Interactive Elements):** `surface_container_highest`

### The "Glass & Gradient" Rule
To achieve the "Bloomberg meets Apple" feel, all primary actions use a signature **"Aegis Glow."**
*   **Action Gradients:** Transition from `primary_container` (#00F5FF) to `secondary_container` (#571BC1) at a 135-degree angle.
*   **Glassmorphism:** Floating modals must use `surface_variant` at 60% opacity with a `24px` backdrop blur. This ensures the institutional "Deep Charcoal" remains visible, maintaining context.

---

## 3. Typography: The Financial Editorial
We use typography to convey precision. Numbers are the hero of this experience.

*   **Display Scale (`plusJakartaSans`):** Used for TVL (Total Value Locked), Wallet Balances, and APY percentages. These should use `display-lg` to command authority.
*   **Body & Label Scale (`inter`):** Used for execution details and fine print. 
*   **The "Monospace Mimicry":** While we use Inter, ensure that numerical displays use `tabular-nums` OpenType features to ensure that ticking financial data does not "jitter" during price updates.
*   **Hierarchy:** `headline-lg` is reserved for page titles, while `title-sm` (all-caps with 0.05em tracking) is used for secondary metadata headers to create an editorial, "Financial Times" feel.

---

## 4. Elevation & Depth
In this system, elevation is a function of light, not lines.

### The Layering Principle
Depth is achieved by "stacking" the surface-container tiers. Place a `surface_container_lowest` card on a `surface_container_low` section to create a soft, natural inset.

### Ambient Shadows
Shadows must never be black. Use the `on_surface` color at 4% opacity with a blur radius of `40px` and a `12px` Y-offset. This mimics a soft glow emanating from the glass panels rather than a heavy object casting a shadow.

### The "Ghost Border"
When high-contrast separation is required (e.g., in a dense data table), use a **Ghost Border**: 1px width using `outline_variant` at 10% opacity. This provides a "hint" of a boundary that disappears into the background on higher-quality displays.

---

## 5. Components

### Buttons (Primary: 'Mint' / 'Deposit')
*   **Style:** Gradient fill (`primary_container` to `secondary_container`).
*   **Shadow:** A `4px` spread glow using the `primary` color at 30% opacity.
*   **Radius:** `full` (pill-shape) to contrast against the `20px` (md) radius of the cards.
*   **Interaction:** On hover, increase the `backdrop-filter: brightness(1.2)`.

### High-Trust Cards
*   **Background:** `surface_container_high` at 80% opacity with backdrop blur.
*   **Edge:** 1px "Ghost Border" using `primary` at 10% opacity to catch the light.
*   **Spacing:** Use `8` (2rem) internal padding to ensure data has "room to breathe."

### Minimal Inputs
*   **Background:** `surface_container_lowest`.
*   **Active State:** No change in border color; instead, the `outline` token glows subtly.
*   **Typography:** User input should use `title-md` for maximum legibility.

### Data Lists
*   **Constraint:** Forbid the use of divider lines. 
*   **Solution:** Use `1.5` (0.375rem) spacing between list items, and use alternating `surface_container_low` and `surface_container` backgrounds for rows to define horizontal rhythm.

---

## 6. Do’s and Don’ts

### Do:
*   **Do** use `primary_fixed_dim` for secondary data points that need to feel "active" but not "urgent."
*   **Do** utilize `tertiary` (#10B981) for success states, ensuring it is paired with `on_tertiary` for AA accessibility.
*   **Do** lean into asymmetry. A large balance on the left can be balanced by a sparse, vertically-oriented navigation menu on the right.

### Don’t:
*   **Don’t** use pure white (#FFFFFF) for text. Always use `on_surface` (#e5e2e3) to reduce eye strain on dark backgrounds.
*   **Don’t** use standard shadows. If a shadow looks "muddy," reduce the opacity and increase the blur.
*   **Don’t** use `none` or `sm` roundedness for primary containers. This system requires the "Apple-esque" softness of `DEFAULT` (20px) or `lg` (32px).